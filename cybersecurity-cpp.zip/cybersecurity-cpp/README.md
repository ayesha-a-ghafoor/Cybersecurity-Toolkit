# C++ Cybersecurity Toolkit

An educational cybersecurity project written in modern C++17.

## Features

| # | Tool | What it does |
|---|------|--------------|
| 1 | **Password Strength Checker** | Scores a password 0-7 based on length, character types, and complexity |
| 2 | **Caesar Cipher** | Encrypts/decrypts text by shifting letters (classic substitution cipher) |
| 3 | **XOR Cipher** | Encrypts/decrypts text using bitwise XOR with a single-character key |
| 4 | **File Integrity Checker** | Hashes any file and detects if it has been modified (tampered with) |

## Build & Run

```bash
# Compile
make

# Run the interactive menu
./cybertools

# Or both at once
make run

# Clean build files
make clean
```

## Project Structure

```
cybersecurity-cpp/
├── main.cpp              # Entry point + interactive menu
├── password_checker.h/cpp  # Password strength analysis
├── caesar_cipher.h/cpp     # Caesar & XOR cipher implementations
├── file_hasher.h/cpp       # File hash & integrity verification
├── Makefile              # Build system
└── README.md
```

## Requirements

- `g++` with C++17 support (standard on most Linux systems)
- No external libraries needed

## Concepts Covered

- **Substitution ciphers** — Caesar cipher (one of the oldest encryption methods)
- **Symmetric encryption** — XOR cipher (same key encrypts and decrypts)
- **Password policy** — Checking complexity rules used in real security systems
- **File integrity** — Hashing to detect unauthorised changes (similar to how MD5/SHA works)

## Acknowledgements

This project was built with the assistance of an AI assistant (Replit Agent).
The code was generated and explained with AI support as a learning tool.
